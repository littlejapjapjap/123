package com.ember.youtubepulse

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.max

private object PulseColors {
    const val BG = 0xFF100C17.toInt()
    const val CARD = 0xFF1B1525.toInt()
    const val CARD_ALT = 0xFF2A2035.toInt()
    const val TEXT = 0xFFFFF5F6.toInt()
    const val MUTED = 0xFFB4A6B8.toInt()
    const val RED = 0xFFFF5364.toInt()
    const val PINK = 0xFFFF9EAA.toInt()
    const val AMBER = 0xFFFFC15C.toInt()
    const val BLUE = 0xFF80B5FF.toInt()
    const val GREEN = 0xFF68DDB8.toInt()
}

class MainActivity : Activity() {
    private var selectedDate = LocalDate.now()
    private var openAccessibilityAfterNotificationRequest = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = PulseColors.BG
        window.navigationBarColor = PulseColors.BG
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val day = YouTubeData.getDay(this, selectedDate)
        val enabled = YouTubeData.trackingEnabled(this)
        val serviceEnabled = YouTubeData.isAccessibilityServiceEnabled(this)
        val scroll = ScrollView(this).apply { setBackgroundColor(PulseColors.BG); isFillViewport = true }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(30))
            setBackgroundColor(PulseColors.BG)
        }
        scroll.addView(page, ScrollView.LayoutParams(-1, -2))
        setContentView(scroll)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBlock.addView(text("YOUTUBE PULSE", 11f, PulseColors.RED, true))
        titleBlock.addView(text("Watch with awareness", 22f, PulseColors.TEXT, true))
        header.addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button(if (enabled) "TRACKING · ON" else "TRACKING · OFF", if (enabled) PulseColors.RED else PulseColors.CARD_ALT) {
            if (enabled) {
                YouTubeData.setTrackingEnabled(this@MainActivity, false)
                render()
            } else {
                enableTrackingAndOpenSettings()
            }
        }, LinearLayout.LayoutParams(-2, dp(42)))
        page.addView(header)
        page.addView(text("ON-DEVICE TRACKER · NO VIDEO OR AUDIO RECORDING", 9f, PulseColors.MUTED, true).apply { setPadding(0, dp(5), 0, dp(17)) })

        val dateRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        dateRow.addView(button("‹", PulseColors.CARD_ALT) { selectedDate = selectedDate.minusDays(1); render() }, LinearLayout.LayoutParams(dp(46), dp(40)))
        val dateCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        dateCol.addView(text(if (selectedDate == LocalDate.now()) "TODAY'S REPORT" else if (selectedDate == LocalDate.now().minusDays(1)) "YESTERDAY'S REPORT" else "DAILY REPORT", 9f, PulseColors.MUTED, true).apply { gravity = Gravity.CENTER })
        dateCol.addView(text(selectedDate.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.ENGLISH)), 14f, PulseColors.TEXT, true).apply { gravity = Gravity.CENTER })
        dateRow.addView(dateCol, LinearLayout.LayoutParams(0, -2, 1f))
        dateRow.addView(button("›", PulseColors.CARD_ALT) { if (selectedDate < LocalDate.now()) { selectedDate = selectedDate.plusDays(1); render() } }, LinearLayout.LayoutParams(dp(46), dp(40)))
        page.addView(dateRow)
        page.addView(space(14))

        if (!serviceEnabled || !enabled) {
            val setup = card()
            setup.addView(text(if (!enabled) "Start a tracking session" else "One permission step left", 17f, PulseColors.TEXT, true))
            val guidance = when {
                !enabled -> "Turn tracking on to begin. Android will ask you to enable the YouTube Pulse accessibility service in Settings. This is required because YouTube does not expose its live play/pause state through a normal app API."
                !serviceEnabled -> "Tracking is armed, but Android's Accessibility Service is not enabled yet. Find “YouTube Pulse Tracker” in Accessibility settings and switch it on."
                else -> "Ready to track."
            }
            setup.addView(text(guidance, 12f, PulseColors.MUTED).apply { setPadding(0, dp(7), 0, dp(12)) })
            setup.addView(button(if (!enabled) "ENABLE TRACKING & OPEN SETTINGS" else "OPEN ACCESSIBILITY SETTINGS", PulseColors.RED) {
                enableTrackingAndOpenSettings()
            })
            page.addView(setup)
            page.addView(space(12))
        }

        val hero = card()
        hero.addView(text("DETECTED WATCH TIME", 10f, PulseColors.MUTED, true))
        hero.addView(text(formatDuration(day.playingMs), 35f, PulseColors.TEXT, true).apply { setPadding(0, dp(5), 0, 0) })
        hero.addView(text("Time YouTube was foregrounded and its player appeared to be playing", 11f, PulseColors.MUTED).apply { setPadding(0, dp(2), 0, dp(13)) })
        val mini = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        mini.addView(miniMetric("YOUTUBE OPEN", formatDuration(day.foregroundMs), PulseColors.BLUE), LinearLayout.LayoutParams(0, -2, 1f))
        mini.addView(miniMetric("PLAYBACK UNCERTAIN", formatDuration(day.unknownMs), PulseColors.MUTED), LinearLayout.LayoutParams(0, -2, 1f))
        hero.addView(mini)
        page.addView(hero)
        page.addView(space(10))

        val metricRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        metricRow1.addView(metricCard("PAUSED IN YOUTUBE", formatDuration(day.pausedMs), "Visible while paused", PulseColors.AMBER), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        metricRow1.addView(metricCard("PLAY / RESUME", day.playbackStarts.toString(), "Detected transitions", PulseColors.RED), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        page.addView(metricRow1)
        page.addView(space(10))
        val metricRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        metricRow2.addView(metricCard("PAUSE EVENTS", day.pauses.toString(), "Detected transitions", PulseColors.PINK), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        metricRow2.addView(metricCard("AVG. PAUSE", if (day.pauses > 0) formatDuration(day.averagePauseMs) else "—", "Pause total ÷ pause events", PulseColors.GREEN), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        page.addView(metricRow2)
        page.addView(space(15))

        val graph = card()
        graph.addView(text("HOURLY PLAYBACK MAP", 15f, PulseColors.TEXT, true))
        graph.addView(text("Detected state per hour · bars show total minutes", 11f, PulseColors.MUTED).apply { setPadding(0, dp(3), 0, dp(7)) })
        graph.addView(HourlyWatchChartView(this, day.hours), LinearLayout.LayoutParams(-1, dp(168)))
        val legend = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, 0) }
        legend.addView(legendItem(PulseColors.RED, "Playing"))
        legend.addView(spaceHorizontal(12))
        legend.addView(legendItem(PulseColors.AMBER, "Paused"))
        legend.addView(spaceHorizontal(12))
        legend.addView(legendItem(PulseColors.BLUE, "Unknown"))
        graph.addView(legend)
        page.addView(graph)
        page.addView(space(12))

        val prompt = card()
        prompt.addView(text("OPEN YOUTUBE → GET A PROMPT", 14f, PulseColors.TEXT, true))
        prompt.addView(text("When tracking is enabled, the service posts a notification when YouTube is detected in the foreground (rate-limited to one prompt per 15 minutes). Tap it to open this dashboard. Enable notifications for the prompt to appear.", 11f, PulseColors.MUTED).apply { setPadding(0, dp(6), 0, dp(10)) })
        if (Build.VERSION.SDK_INT >= 33) {
            prompt.addView(button("REQUEST NOTIFICATION PERMISSION", PulseColors.CARD_ALT) { requestNotificationPermissionIfNeeded(force = true) })
        }
        page.addView(prompt)
        page.addView(space(12))

        val privacy = card()
        privacy.addView(text("HOW THE ESTIMATES WORK", 14f, PulseColors.TEXT, true))
        privacy.addView(text("The service checks YouTube's accessibility labels for a Pause or Play control. A visible Pause action usually means the video is playing; a Play action usually means it is paused. If neither label is available, time is counted as YouTube-open / state-unknown. Playback starts mean detected transitions into playing, not guaranteed unique videos. Autoplaying the next video may not create a new count. Screen-off time is excluded. Results vary with YouTube version, language, player layout, and Android firmware.", 11f, PulseColors.MUTED).apply { setPadding(0, dp(6), 0, 0) })
        page.addView(privacy)
        page.addView(space(12))
        page.addView(button("CLEAR ALL LOCAL TRACKING DATA", PulseColors.CARD_ALT) {
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Clear YouTube Pulse data?")
                .setMessage("This deletes the saved daily hour totals and counters from this phone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ ->
                    YouTubeData.prefs(this@MainActivity).edit().clear().putBoolean("tracking_enabled", false).apply()
                    render()
                }
                .show()
        }, LinearLayout.LayoutParams(-1, dp(44)))
    }

    private fun enableTrackingAndOpenSettings() {
        YouTubeData.setTrackingEnabled(this, true)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            openAccessibilityAfterNotificationRequest = true
            runCatching { requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 826) }
        } else {
            runCatching { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        render()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 826 && openAccessibilityAfterNotificationRequest) {
            openAccessibilityAfterNotificationRequest = false
            runCatching { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
    }

    private fun requestNotificationPermissionIfNeeded(force: Boolean = false) {
        if (Build.VERSION.SDK_INT >= 33 && (force || checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)) {
            runCatching { requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 825) }
        }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        background = rounded(PulseColors.CARD, 18)
    }

    private fun miniMetric(title: String, value: String, color: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(9), dp(9), dp(5), dp(1))
        addView(text(title, 9f, color, true))
        addView(text(value, 17f, PulseColors.TEXT, true).apply { setPadding(0, dp(3), 0, 0) })
    }

    private fun metricCard(title: String, value: String, caption: String, color: Int) = card().apply {
        addView(text(title, 9f, color, true))
        addView(text(value, 23f, PulseColors.TEXT, true).apply { setPadding(0, dp(5), 0, dp(1)) })
        addView(text(caption, 10f, PulseColors.MUTED))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        includeFontPadding = false
    }

    private fun button(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 10f
        setTextColor(if (color == PulseColors.RED || color == PulseColors.AMBER || color == PulseColors.GREEN) 0xFF190E17.toInt() else PulseColors.TEXT)
        isAllCaps = false
        background = rounded(color, 12)
        setPadding(dp(10), 0, dp(10), 0)
        minHeight = dp(38); minimumHeight = dp(38); stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun legendItem(color: Int, label: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(View(this@MainActivity).apply { background = rounded(color, 4) }, LinearLayout.LayoutParams(dp(8), dp(8)))
        addView(text(label, 9f, PulseColors.MUTED).apply { setPadding(dp(5), 0, 0, 0) })
    }

    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun spaceHorizontal(width: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(width), 1) }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

private fun formatDuration(ms: Long): String {
    val total = max(0L, ms / 60_000L)
    val h = total / 60
    val m = total % 60
    return if (h > 0) "${h}h ${m}m" else "${m}m"
}

private class HourlyWatchChartView(context: Context, private val hours: List<HourRecord>) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = dp(2f); val right = width - dp(2f); val top = dp(9f); val bottom = height - dp(27f)
        val chartHeight = bottom - top
        val colGap = dp(3f)
        val colWidth = (right - left - 23f * colGap) / 24f
        val maxMs = max(60_000L, hours.maxOfOrNull { it.foregroundMs } ?: 60_000L)
        paint.color = 0xFF302538.toInt()
        for (i in 0 until 24) {
            val x = left + i * (colWidth + colGap)
            canvas.drawRoundRect(RectF(x, top, x + colWidth, bottom), dp(3f), dp(3f), paint)
            val hour = hours.getOrNull(i) ?: HourRecord(i, 0, 0, 0, 0, 0, 0)
            var y = bottom
            val segments = listOf(hour.playingMs to PulseColors.RED, hour.pausedMs to PulseColors.AMBER, hour.unknownMs to PulseColors.BLUE)
            segments.forEach { (duration, color) ->
                val h = chartHeight * (duration.toFloat() / maxMs).coerceIn(0f, 1f)
                if (h > 0f) {
                    paint.color = color
                    canvas.drawRoundRect(RectF(x, y - h, x + colWidth, y), dp(2f), dp(2f), paint)
                    y -= h
                }
            }
        }
        paint.color = PulseColors.MUTED
        paint.textSize = dp(9f)
        paint.typeface = android.graphics.Typeface.DEFAULT
        val labels = listOf(0 to "00", 6 to "06", 12 to "12", 18 to "18", 23 to "24")
        labels.forEach { (h, label) ->
            val x = left + h * (colWidth + colGap) + colWidth / 2f - paint.measureText(label) / 2f
            canvas.drawText(label, x, height - dp(5f), paint)
        }
    }
    private fun dp(v: Float) = v * resources.displayMetrics.density
}
