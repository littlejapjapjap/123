package com.ember.youtubepulse

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.app.Notification
import java.util.Locale
import java.util.ArrayDeque

class YouTubeWatchAccessibilityService : AccessibilityService() {
    companion object {
        private const val YOUTUBE_PACKAGE = "com.google.android.youtube"
        private const val CHANNEL_ID = "youtube_pulse_prompt"
        private const val NOTIFICATION_ID = 6201
        private const val PROMPT_COOLDOWN_MS = 15L * 60L * 1000L
    }

    private var youtubeForeground = false
    private var currentPlaying: Boolean? = null
    private var lastTick = System.currentTimeMillis()
    private val handler = Handler(Looper.getMainLooper())
    private var serviceStarted = false

    private val ticker = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            advance(now)
            if (youtubeForeground && YouTubeData.trackingEnabled(this@YouTubeWatchAccessibilityService)) {
                inferPlaybackState(getRootInActiveWindow())?.let { updatePlaybackState(it, now) }
            }
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        createNotificationChannel()
        lastTick = System.currentTimeMillis()
        serviceStarted = true
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, 60_000L)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val now = System.currentTimeMillis()
        if (!YouTubeData.trackingEnabled(this)) {
            advance(now)
            youtubeForeground = false
            currentPlaying = null
            lastTick = now
            return
        }

        val packageName = event.packageName?.toString().orEmpty()
        val isYoutube = packageName == YOUTUBE_PACKAGE
        if (isYoutube && !youtubeForeground) {
            advance(now)
            youtubeForeground = true
            currentPlaying = null
            lastTick = now
            maybePromptToOpenTracker(now)
        } else if (!isYoutube && youtubeForeground) {
            advance(now)
            youtubeForeground = false
            currentPlaying = null
            lastTick = now
        }

        if (isYoutube && youtubeForeground && event.eventType in setOf(
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
                AccessibilityEvent.TYPE_VIEW_CLICKED,
                AccessibilityEvent.TYPE_WINDOWS_CHANGED
            )) {
            val root = runCatching { rootInActiveWindow }.getOrNull()
            inferPlaybackState(root)?.let { updatePlaybackState(it, now) }
        }
    }

    private fun updatePlaybackState(nextState: Boolean, now: Long) {
        if (nextState == currentPlaying) return
        advance(now)
        if (nextState) {
            YouTubeData.recordPlaybackStart(this, now)
        } else if (currentPlaying == true) {
            YouTubeData.recordPause(this, now)
        }
        currentPlaying = nextState
        lastTick = now
    }

    private fun advance(now: Long) {
        if (now > lastTick && youtubeForeground && YouTubeData.trackingEnabled(this) && isScreenInteractive()) {
            YouTubeData.addInterval(this, lastTick, now, currentPlaying)
        }
        lastTick = now
    }

    private fun isScreenInteractive(): Boolean {
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        return power.isInteractive
    }

    @Suppress("DEPRECATION")
    private fun inferPlaybackState(root: AccessibilityNodeInfo?): Boolean? {
        if (root == null) return null
        if (root.packageName?.toString() != YOUTUBE_PACKAGE) {
            root.recycle()
            return null
        }
        val labels = ArrayList<String>(24)
        val pending = ArrayDeque<AccessibilityNodeInfo>()
        pending.add(root)
        var visited = 0
        while (pending.isNotEmpty() && visited < 320) {
            val node = pending.removeFirst()
            visited++
            try {
                val desc = node.contentDescription?.toString()?.trim().orEmpty()
                val text = node.text?.toString()?.trim().orEmpty()
                if (desc.isNotEmpty() && (node.isClickable || looksLikePlaybackLabel(desc))) labels.add(desc.lowercase(Locale.ROOT))
                if (text.isNotEmpty() && (node.isClickable || looksLikePlaybackLabel(text))) labels.add(text.lowercase(Locale.ROOT))
                for (i in 0 until node.childCount) {
                    val child = runCatching { node.getChild(i) }.getOrNull() ?: continue
                    pending.add(child)
                }
            } finally {
                node.recycle()
            }
        }
        while (pending.isNotEmpty()) runCatching { pending.removeFirst().recycle() }
        val pause = labels.any { isPauseAction(it) }
        val play = labels.any { isPlayAction(it) }
        return when {
            pause -> true
            play -> false
            else -> null
        }
    }

    private fun looksLikePlaybackLabel(text: String): Boolean {
        val s = text.lowercase(Locale.ROOT)
        return listOf("pause", "play video", "playback", "воспроиз", "призуп", "відтвор", "пауза", "resume").any { s.contains(it) }
    }

    private fun isPauseAction(label: String): Boolean {
        val s = label.trim().lowercase(Locale.ROOT)
        return s == "pause" || s == "pause video" || s.startsWith("pause video") || s.startsWith("pause playback") ||
            s == "пауза" || s.contains("поставить на паузу") || s.contains("призупинити відео") || s.contains("призупинити")
    }

    private fun isPlayAction(label: String): Boolean {
        val s = label.trim().lowercase(Locale.ROOT)
        return s == "play" || s == "play video" || s.startsWith("play video") || s == "resume" ||
            s.contains("воспроизвести видео") || s == "воспроизвести" || s.contains("відтворити відео") ||
            s == "відтворити" || s.contains("відновити відтворення")
    }

    private fun maybePromptToOpenTracker(now: Long) {
        val prefs = YouTubeData.prefs(this)
        val lastPrompt = prefs.getLong("last_prompt_at", 0L)
        if (now - lastPrompt < PROMPT_COOLDOWN_MS) return
        prefs.edit().putLong("last_prompt_at", now).apply()
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val openIntent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val content = PendingIntent.getActivity(this, 6202, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Track this YouTube session?")
            .setContentText("YouTube is open. Tap to view your watch and pause stats.")
            .setContentIntent(content)
            .addAction(android.R.drawable.ic_media_play, "OPEN TRACKER", content)
            .setAutoCancel(true)
            .build()
        runCatching { manager.notify(NOTIFICATION_ID, notification) }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "YouTube session prompts", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "A reminder when YouTube opens; the tracker itself runs only when enabled."
            })
        }
    }

    override fun onInterrupt() {
        advance(System.currentTimeMillis())
        youtubeForeground = false
        currentPlaying = null
    }

    override fun onDestroy() {
        if (serviceStarted) advance(System.currentTimeMillis())
        handler.removeCallbacks(ticker)
        youtubeForeground = false
        currentPlaying = null
        super.onDestroy()
    }
}
