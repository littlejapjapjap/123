package com.ember.youtubepulse

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.text.TextUtils
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.max
import kotlin.math.min

data class HourRecord(
    val hour: Int,
    val foregroundMs: Long,
    val playingMs: Long,
    val pausedMs: Long,
    val unknownMs: Long,
    val playbackStarts: Int,
    val pauses: Int
)

data class YouTubeDay(
    val date: LocalDate,
    val hours: List<HourRecord>
) {
    val foregroundMs get() = hours.sumOf { it.foregroundMs }
    val playingMs get() = hours.sumOf { it.playingMs }
    val pausedMs get() = hours.sumOf { it.pausedMs }
    val unknownMs get() = hours.sumOf { it.unknownMs }
    val playbackStarts get() = hours.sumOf { it.playbackStarts }
    val pauses get() = hours.sumOf { it.pauses }
    val averagePauseMs get() = if (pauses > 0) pausedMs / pauses else 0L
}

object YouTubeData {
    private const val PREFS = "youtube_pulse_data"
    private const val DATES_KEY = "saved_dates"
    private val zone get() = ZoneId.systemDefault()
    private val formatter = DateTimeFormatter.ISO_LOCAL_DATE

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun trackingEnabled(context: Context) = prefs(context).getBoolean("tracking_enabled", false)
    fun setTrackingEnabled(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean("tracking_enabled", enabled).apply()

    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expected = ComponentName(context, YouTubeWatchAccessibilityService::class.java).flattenToString()
        val raw = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(raw)
        while (splitter.hasNext()) {
            val service = splitter.next()
            if (service.equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    private fun emptyDay(date: String): JSONObject {
        val arr = JSONArray()
        repeat(24) { hour -> arr.put(JSONObject().put("h", hour).put("f", 0L).put("w", 0L).put("p", 0L).put("u", 0L).put("s", 0).put("c", 0)) }
        return JSONObject().put("date", date).put("hours", arr)
    }

    private fun readDayJson(context: Context, date: String): JSONObject {
        val key = "day_$date"
        val existing = prefs(context).getString(key, null)
        if (existing == null) return emptyDay(date)
        return runCatching { JSONObject(existing) }.getOrElse { emptyDay(date) }
    }

    fun addInterval(context: Context, startMs: Long, endMs: Long, playing: Boolean?) {
        if (endMs <= startMs) return
        val prefs = prefs(context)
        val editor = prefs.edit()
        val dayObjects = linkedMapOf<String, JSONObject>()
        var cursor = startMs
        var safety = 0
        while (cursor < endMs && safety++ < 80) {
            val local = Instant.ofEpochMilli(cursor).atZone(zone)
            val dateKey = local.toLocalDate().format(formatter)
            val nextHour = local.withMinute(0).withSecond(0).withNano(0).plusHours(1).toInstant().toEpochMilli()
            val boundary = min(endMs, max(cursor + 1L, nextHour))
            val part = boundary - cursor
            val day = dayObjects.getOrPut(dateKey) { readDayJson(context, dateKey) }
            val hours = day.optJSONArray("hours") ?: JSONArray()
            val hourIndex = local.hour.coerceIn(0, 23)
            val bucket = hours.optJSONObject(hourIndex) ?: JSONObject().put("h", hourIndex).put("f", 0L).put("w", 0L).put("p", 0L).put("u", 0L).put("s", 0).put("c", 0)
            bucket.put("f", bucket.optLong("f") + part)
            when (playing) {
                true -> bucket.put("w", bucket.optLong("w") + part)
                false -> bucket.put("p", bucket.optLong("p") + part)
                null -> bucket.put("u", bucket.optLong("u") + part)
            }
            hours.put(hourIndex, bucket)
            day.put("hours", hours)
            cursor = boundary
        }
        dayObjects.forEach { (date, day) -> editor.putString("day_$date", day.toString()) }
        updateDates(context, editor, dayObjects.keys)
        editor.apply()
    }

    fun recordPlaybackStart(context: Context, atMs: Long) = updateCounter(context, atMs, "s")
    fun recordPause(context: Context, atMs: Long) = updateCounter(context, atMs, "c")

    private fun updateCounter(context: Context, atMs: Long, field: String) {
        val date = Instant.ofEpochMilli(atMs).atZone(zone).toLocalDate().format(formatter)
        val day = readDayJson(context, date)
        val arr = day.optJSONArray("hours") ?: JSONArray()
        val hour = Instant.ofEpochMilli(atMs).atZone(zone).hour.coerceIn(0, 23)
        val bucket = arr.optJSONObject(hour) ?: JSONObject().put("h", hour).put("f", 0L).put("w", 0L).put("p", 0L).put("u", 0L).put("s", 0).put("c", 0)
        bucket.put(field, bucket.optInt(field) + 1)
        arr.put(hour, bucket)
        day.put("hours", arr)
        val editor = prefs(context).edit().putString("day_$date", day.toString())
        updateDates(context, editor, listOf(date))
        editor.apply()
    }

    private fun updateDates(context: Context, editor: android.content.SharedPreferences.Editor, newDates: Collection<String>) {
        val raw = prefs(context).getString(DATES_KEY, "[]") ?: "[]"
        val current = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        val set = linkedSetOf<String>()
        for (i in 0 until current.length()) current.optString(i).takeIf { it.isNotBlank() }?.let(set::add)
        set.addAll(newDates)
        val keep = set.sortedDescending().take(90)
        editor.putString(DATES_KEY, JSONArray().also { arr -> keep.forEach { arr.put(it) } }.toString())
        (set - keep.toSet()).forEach { editor.remove("day_$it") }
    }

    fun getDay(context: Context, date: LocalDate = LocalDate.now()): YouTubeDay {
        val key = date.format(formatter)
        val day = readDayJson(context, key)
        val arr = day.optJSONArray("hours") ?: JSONArray()
        val hours = (0..23).map { hour ->
            val b = arr.optJSONObject(hour) ?: JSONObject()
            HourRecord(
                hour,
                b.optLong("f"),
                b.optLong("w"),
                b.optLong("p"),
                b.optLong("u"),
                b.optInt("s"),
                b.optInt("c")
            )
        }
        return YouTubeDay(date, hours)
    }
}
