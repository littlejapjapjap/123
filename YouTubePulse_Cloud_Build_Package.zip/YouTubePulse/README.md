# YouTube Pulse — local watch / pause estimator

A native Kotlin Android Studio project. YouTube does not expose a dependable public API for another installed app to read the current playback state, so this project uses an optional Android Accessibility Service and labels its counters as estimates.

## Features

- Custom dark dashboard with daily play-time, YouTube foreground time, visible paused time, detected play/resume transitions, pause transitions and average pause length.
- 24-column hourly graph: red = detected playing, amber = detected paused, blue = YouTube foreground but the playback state could not be read.
- When tracking is enabled and YouTube enters the foreground, the service posts a **Track this YouTube session?** notification with an **Open tracker** action. To avoid notification spam, prompts are rate-limited to one per 15 minutes.
- Data is kept locally in app-private storage for up to 90 date buckets. No media, microphone audio, video frames or screenshots are recorded. No network access is declared.
- The accessibility service samples state when events arrive and at a one-minute interval. It traverses at most 320 nodes and recycles accessibility nodes to keep overhead low.

## Install / build

1. Install Android Studio and Android SDK Platform 35, using JDK 17.
2. Open this project folder in Android Studio and let Gradle sync. The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21. The included `gradlew` / `gradlew.bat` bootstrap Gradle 8.9 from the official Gradle distribution on first use.
3. Alternatively, run `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`) from the project folder.
4. Select **Build → Build APK(s)**, then install the debug APK.
5. Open YouTube Pulse and turn **TRACKING · OFF** to **TRACKING · ON**. Android opens Accessibility settings.
6. Find **YouTube Pulse Tracker** and enable it. This special permission must be granted manually in Android settings. The code only inspects accessible labels when the event belongs to the official YouTube package; other package events are used only to detect leaving YouTube.
7. Allow notifications if you want the “Open tracker” prompt when YouTube is opened. Tracking can still collect in the background without notification permission after the Accessibility Service is enabled.

Minimum Android version: Android 8 (API 26).

## Measurement limits

- The service uses accessible button labels such as “Pause” or “Play video” to infer the player's state. YouTube UI, language, ads, Shorts, mini-player overlays, and app updates can make labels unavailable or ambiguous.
- **Play / resume** is a detected transition into the playing state, not a guaranteed count of unique videos. Autoplaying the next video may not increment it.
- Time is only counted while YouTube is in the foreground and the phone screen is interactive. Background audio with the screen off is excluded by design.
- If no player control label can be read, that interval is shown as “Playback uncertain” rather than being guessed as watch or pause time.
- Accessibility permission is powerful. Enable this only if you are comfortable with the stated local behavior; revoke it at any time from Android Accessibility settings.
