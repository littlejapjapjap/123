@echo off
setlocal
set "GRADLE_VERSION=8.9"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "BOOTSTRAP_ROOT=%GRADLE_USER_HOME%\gradle-bootstrap"
set "GRADLE_DIST=%BOOTSTRAP_ROOT%\gradle-%GRADLE_VERSION%"
if not exist "%GRADLE_DIST%\bin\gradle.bat" (
  if not exist "%BOOTSTRAP_ROOT%" mkdir "%BOOTSTRAP_ROOT%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $url='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; $zip=Join-Path $env:GRADLE_USER_HOME 'gradle-bootstrap\gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest -Uri $url -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath (Split-Path $zip -Parent) -Force; Remove-Item -LiteralPath $zip -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_DIST%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
